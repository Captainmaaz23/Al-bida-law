<!doctype html>
<html lang="<?php echo e(config('app.locale')); ?>">
    <head>
        <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('headerInclude'); ?>
    </head>
    <body>
        <?php
        $container_class = "sidebar-o enable-page-overlay side-scroll page-header-fixed main-content-narrow";
        if (Auth::user()) {
            $header = Auth::user()->header;
            $sidebar = Auth::user()->sidebar;

            if ($header == 'dark' && $sidebar == 'dark')
                $container_class .= " page-header-dark sidebar-dark";
            elseif ($header == 'dark')
                $container_class .= " page-header-dark";
            elseif ($sidebar == 'dark')
                $container_class .= " sidebar-dark";
        }
        ?>

        <div id="page-container" class="<?php echo $container_class; ?>">


            <?php echo $__env->make('layouts.aside', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <main id="main-container">

                <?php echo $__env->yieldContent('content'); ?>

            </main>

            <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>

        <?php echo $__env->make('layouts.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('footerInclude'); ?>
        <?php echo $__env->make('select2.select2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </body>
</html><?php /**PATH /home2/logicva1/sub_demos/sufra_v2/resources/views/layouts/app.blade.php ENDPATH**/ ?>