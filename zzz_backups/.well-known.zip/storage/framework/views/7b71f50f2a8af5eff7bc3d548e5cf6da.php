

<?php $__env->startSection('content'); ?>

<div class="bg-body-light">
    <div class="content">
        <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
            <h1 class="flex-sm-fill h3 my-2">Roles</h1>
        </div>
        <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
            <nav class="flex-sm-00-auto" aria-label="breadcrumb">
                <ol class="breadcrumb breadcrumb-alt">
                    <li class="breadcrumb-item">
                        <a class="link-fx" href="<?php echo e(route('dashboard')); ?>">Home</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Roles</li>
                </ol>
            </nav> 
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['roles-add', 'all'])): ?>
            <a href="#" data-toggle="modal" data-target="#createModal" class="btn btn-primary btn-add-new pull-right">
                <i class="fa fa-plus-square fa-lg"></i> Add New
            </a>
            <?php endif; ?>
        </div>
        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<div class="content">                
    <div class="block block-rounded block-themed">
        <div class="block-content">
            <?php if($recordsExists): ?>
            <form method="post" role="form" id="data-search-form">
                <div class="table-responsive">
                    <table class="table table-striped table-hover" id="myDataTable">
                        <thead>
                            <tr role="row" class="heading">                                                 
                                <td>
                                    <input type="text" class="form-control" id="s_title" autocomplete="off" placeholder="Title">
                                </td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr role="row" class="heading">
                                <th>Title</th>
                                <th>Action</th>                                                    
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </form>
            <?php else: ?>
            <p class="text-center font-weight-bold py-5">No Records Available</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php if(auth()->user()->can('roles-add') || auth()->user()->can('all')): ?>
<div class="modal" id="createModal" tabindex="-1" role="dialog" aria-labelledby="createModal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="block block-rounded block-themed mb-0">
                <div class="block-header block-header-default">
                    <h3 class="block-title">Add New</h3>
                    <div class="block-options">
                        <button type="button" class="btn-block-option" data-bs-dismiss="modal" aria-label="Close">
                            <i class="fa fa-fw fa-times"></i>
                        </button>
                    </div>
                </div>
                <form action="<?php echo e(route('roles.store')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="block-content fs-sm">
                        <?php echo $__env->make('roles.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php if($recordsExists): ?>
<?php $__env->startSection('headerInclude'); ?>
<?php echo $__env->make('datatables.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footerInclude'); ?>
<?php echo $__env->make('datatables.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startPush('scripts'); ?> 
<script>
    jQuery(document).ready(function () {
    <?php if($recordsExists): ?>
            var oTable = $('#myDataTable').DataTable({
    processing: true,
            serverSide: true,
            stateSave: true,
            searching: false,
            dom: 'Blfrtip',
            autoWidth: false,
            buttons: [
            {
            extend: 'excel',
                    exportOptions: { columns: ':visible' }
            },
            {
            extend: 'pdf',
                    exportOptions: { columns: ':visible' }
            },
            {
            extend: 'print',
                    exportOptions: { columns: ':visible' }
            },
                    'colvis'
            ],
            ajax: {
            url: "<?php echo route('roles_datatable'); ?>",
                    data: function (d) {
                    d.title = $('#s_title').val();
                    }
            },
            columns: [
            { data: 'title', name: 'title' },
            { data: 'action', name: 'action' }
            ]
    });
    $('#s_title').on('keyup', function (e) {
    oTable.draw();
    e.preventDefault();
    });
    <?php endif; ?>
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/logicva1/sub_demos/sufra_v2/resources/views/roles/listing.blade.php ENDPATH**/ ?>