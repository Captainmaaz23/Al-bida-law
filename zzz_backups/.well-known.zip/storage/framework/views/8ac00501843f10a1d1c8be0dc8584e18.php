<?php $__env->startSection('content'); ?>
<?php $AUTH_USER = Auth::user(); ?>

<div class="bg-body-light">
    <div class="content">
        <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
            <h1 class="flex-sm-fill h3 my-2"><?php echo e($list_title); ?></h1>
        </div>
        <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
            <nav class="flex-sm-00-auto" aria-label="breadcrumb">
                <ol class="breadcrumb breadcrumb-alt">
                    <li class="breadcrumb-item">
                        <a class="link-fx" href="<?php echo e(route('dashboard')); ?>">Home</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Orders</li>
                </ol>
            </nav>
        </div>
        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<div class="content">
    <div class="block block-rounded block-themed">
        <div class="block-content">
            <?php if($recordsExists == 1): ?>
            <form method="post" role="form" id="data-search-form">
                <div class="table-responsive">
                    <table class="table table-striped table-hover" id="myDataTable">
                        <thead>
                            <tr role="row" class="heading">
                                <?php if($AUTH_USER->rest_id == 0): ?>
                                    <td>
                                        <select class="form-control js-select2 form-select rest_select2" id="s_rest_id">
                                            <option value="-1">Select</option>
                                            <?php $__currentLoopData = $restaurants_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </td>
                                <?php endif; ?>
                                <td><input type="text" class="form-control" id="s_order_no" autocomplete="off" placeholder="Order No"></td>
                                <td>
                                    <select class="form-control" id="s_user_id">
                                        <option value="-1">Select</option>
                                        <?php $__currentLoopData = $users_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($value->user_id); ?>"><?php echo e($value->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>
                                <td>
                                    <select class="form-control" id="s_table_id">
                                        <option value="-1">Select</option>
                                        <?php $__currentLoopData = $tables_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>
                                <td><input type="number" class="form-control" id="s_order_value" autocomplete="off" placeholder="Order Value"></td>
                                <td>
                                    <select class="form-control" id="s_status">
                                        <?php $__currentLoopData = $filter_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($value); ?>" <?php echo e(isset($filter_status) && $value == $filter_status ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </td>
                                <td>&nbsp;</td>
                            </tr>
                            <tr role="row" class="heading">
                                <?php if($AUTH_USER->rest_id == 0): ?>
                                <th>Restaurant</th>
                                <?php endif; ?>
                                <th>Order No</th>
                                <th>User</th>
                                <th>Table</th>
                                <th>Order Value</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody></tbody>
                    </table>
                </div>
            </form>
            <?php else: ?>
            <p class="text-center font-weight-bold py-5">No Records Available</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php if($recordsExists == 1): ?>
<?php $__env->startSection('headerInclude'); ?>
<?php echo $__env->make('datatables.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footerInclude'); ?>
<?php echo $__env->make('datatables.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startPush('scripts'); ?>
<script>
    jQuery(document).ready(function () {
        <?php if($recordsExists == 1): ?>
            var oTable = $('#myDataTable').DataTable({
                processing: true,
                serverSide: true,
                stateSave: true,
                searching: false,
                dom: 'Blfrtip',
                autoWidth: false,
                buttons: [
                    { extend: 'excel', exportOptions: { columns: ':visible' }},
                    { extend: 'pdf', exportOptions: { columns: ':visible' }},
                    { extend: 'print', exportOptions: { columns: ':visible' }},
                    'colvis'
                ],
                columnDefs: [{ targets: -1, visible: true }],
                ajax: {
                    url: "<?php echo route('orders_datatable'); ?>",
                    data: function (d) {
                        <?php if($AUTH_USER->rest_id == 0): ?>
                            d.rest_id = $('#s_rest_id').val();
                        <?php endif; ?>                        
                        d.order_no = $('#s_order_no').val();
                        d.table_id = $('#s_table_id').val();
                        d.order_value = $('#s_order_value').val();
                        d.status = $('#s_status').val();
                    }
                },
                columns: [
                    <?php if($AUTH_USER->rest_id == 0): ?>
                        { data: 'rest_id', name: 'rest_id' },
                    <?php endif; ?>
                    {data: 'order_no', name: 'order_no'},
                    {data: 'user_id', name: 'user_id'},
                    {data: 'table_id', name: 'table_id'},
                    {data: 'order_value', name: 'order_value'},
                    {data: 'status', name: 'status'},
                    {data: 'action', name: 'action'}
                ]
            });

            $('#data-search-form').on('submit', function (e) {
                oTable.draw();
                e.preventDefault();
            });

            $('#s_rest_id, #s_order_no, #s_user_id, #s_table_id, #s_order_value, #s_status').on('change keyup', function (e) {
                oTable.draw();
                e.preventDefault();
            });
        <?php endif; ?>
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/logicva1/sub_demos/sufra_v2/resources/views/restaurants/orders/listing.blade.php ENDPATH**/ ?>