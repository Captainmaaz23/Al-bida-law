
<script src="<?php echo e(asset_url('bundles/datatables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset_url('bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js')); ?>"></script><?php /**PATH /home2/logicva1/sub_demos/sufra_v2/resources/views/datatables/js.blade.php ENDPATH**/ ?>