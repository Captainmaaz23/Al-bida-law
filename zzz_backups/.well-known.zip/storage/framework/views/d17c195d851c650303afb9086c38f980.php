<?php
$array = [
    '0' => 'No',
    '1' => 'Yes'
];

$item_id = isset($Model_Data) ? $Model_Data->item_id : 0;
$class = isset($Model_Data) ? 'col-sm-8' : 'col-sm-12';
?>

<div class="row justify-content-center mt-2 mb-2 form-group">
    <div class="<?php echo e($class); ?>">
        <div class="form-group row mt-3">
            <div class="col-sm-4">
                <label for="item_id">Item:</label>
            </div>
            <div class="col-sm-8">
                <select name="<?php echo e(isset($Model_Data->item_id) ? 'item_id_2' : 'item_id'); ?>" class="form-control js-select2 form-select item_select2" <?php echo e(isset($Model_Data->item_id) ? 'disabled' : ''); ?>>
                    <option value="" selected disabled>select</option>
                    <?php $__currentLoopData = $Items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($id); ?>" <?php echo e((isset($Model_Data->item_id) && $id == $Model_Data->item_id) ? 'selected' : ''); ?>><?php echo e($name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <?php if(isset($Model_Data->item_id)): ?>
            <input type="hidden" id="item_id" name="item_id" value="<?php echo e($Model_Data->item_id); ?>" />
        <?php endif; ?>

        <div class="row mt-3">
            <div class="col-sm-4">
                <label for="title">Name:</label>
            </div>
            <div class="col-sm-8">
                <input type="text" name="title" class="form-control" value="">
            </div>
        </div>

        <div class="form-group row mt-3">
            <div class="col-sm-4">
                <label for="is_mandatory">Mandatory:</label>
            </div>
            <div class="col-sm-8">
                <select name="is_mandatory" class="form-control" required>
                    <option value="" selected disabled>select</option>
                    <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>"><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="form-group row mt-3">
            <div class="col-sm-4">
                <label for="is_multi_select">Multi-Select:</label>
            </div>
            <div class="col-sm-8">
                <select name="is_multi_select" class="form-control" required>
                    <option value="" selected disabled>select</option>
                    <?php $__currentLoopData = $array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>"><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="form-group row mt-3">
            <div class="col-sm-4">
                <label for="max_selection">Maximum Selection:</label>
            </div>
            <div class="col-sm-8">			
                <input type="number" name="max_selection" class="form-control" required min="0" max="10">
            </div>
        </div>

        <div class="row mt-3">
            <div class="col-sm-4">
                <label for="file_upload">Image:</label>
            </div>
            <div class="col-sm-8">
                <input type="file" name="file_upload" class="form-control">
            </div>
        </div>

        <div class="row mt-3">
            <div class="col-sm-12 text-center">
                <button type="submit" class="btn btn-primary">Save</button>
                <?php if(isset($Model_Data->item_id)): ?>
                    <a href="<?php echo e(route('items.edit', $Model_Data->item_id)); ?>" class="btn btn-outline-dark">Cancel</a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php if(isset($Model_Data->icon)): ?>
        <div class="col-sm-4">
            <img id="image" src="<?php echo e(uploads(isset($Model_Data->icon) && $Model_Data->icon == 'addon_type.png' ? 'defaults/' : 'addon_types/' . $Model_Data->icon)); ?>" class="img-thumbnail img-responsive cust_img_cls" alt="Image" />
        </div>
    <?php endif; ?>
</div><?php /**PATH /home2/logicva1/sub_demos/sufra_v2/resources/views/addon_types/fields.blade.php ENDPATH**/ ?>