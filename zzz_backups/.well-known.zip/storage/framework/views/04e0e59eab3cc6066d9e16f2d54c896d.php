<?php
$availability = [
    '0' => "Not Available",
    '1' => "Available",
];
?>

<div class="row justify-content-center mt-2 mb-2 form-group">
    <div class="col-sm-6">

        <?php if(Auth::user()->rest_id == 0): ?>
            <div class="form-group row mt-3">
                <div class="col-sm-4">
                    <label for="rest_id">Restaurant:</label>
                </div>
                <div class="col-sm-8">
                    <select name="rest_id" class="form-control js-select2 form-select rest_select2" <?php echo e(isset($Model_Data->rest_id) ? 'disabled' : ''); ?>>
                        <option value="" <?php echo e(!isset($Model_Data->rest_id) ? 'disabled selected' : ''); ?>>Select</option>
                        <?php $__currentLoopData = $restaurants_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php echo e(isset($Model_Data->rest_id) && $value == $Model_Data->rest_id ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        <?php else: ?>
            <input type="hidden" id="rest_id" name="rest_id" value="<?php echo e(Auth::user()->rest_id); ?>" />
        <?php endif; ?>

        <div class="form-group row mt-3">
            <div class="col-sm-4">
                <label for="title">Title:</label>
            </div>
            <div class="col-sm-8">
                <input type="text" name="title" class="form-control" value="<?php echo e((isset($Model_Data->title)) ? $Model_Data->title : old('title')); ?>">
                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="form-group row mt-3">
            <div class="col-sm-4">
                <label for="file_upload">Image:</label>
            </div>
            <div class="col-sm-8">
                <input type="file" name="file_upload" class="form-control">
            </div>
        </div>

        <div class="form-group row mt-3">
            <div class="col-sm-4">
                <label for="availability">Availability:</label>
            </div>
            <div class="col-sm-8">
                <select name="availability" class="form-control" required>
                    <option value="" selected disabled>Select</option>
                    <?php $__currentLoopData = $availability; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>" <?php echo e((isset($Model_Data->availability) && $value == $Model_Data->availability) ? 'selected' : ''); ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </div>

        <div class="form-group row mt-3 mb-3">
            <div class="col-sm-12 text-center">
                <button type="submit" class="btn btn-primary">Save</button>
                <a href="<?php echo e(route('menus.index')); ?>" class='btn btn-outline-dark'>Cancel</a>
            </div>
        </div>
    </div>

    <?php if(isset($Model_Data->icon)): ?>
        <?php
            $image = $Model_Data->icon;
            $image_path = ($image == 'menu.png') ? 'defaults/' : 'menus/';
            $image_path .= $image;
        ?>
        <div class="col-sm-6 text-center">
            <img id="image" src="<?php echo e(uploads($image_path)); ?>" class="img-thumbnail img-responsive cust_img_cls" alt="Image" />
        </div>
    <?php endif; ?>
</div>
<?php /**PATH /home2/logicva1/sub_demos/sufra_v2/resources/views/restaurants/menus/fields.blade.php ENDPATH**/ ?>