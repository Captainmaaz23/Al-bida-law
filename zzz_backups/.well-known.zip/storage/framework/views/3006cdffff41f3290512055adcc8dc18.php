<?php $__env->startSection('content'); ?>
<div class="bg-body-light">
    <div class="content">
        <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
            <h1 class="flex-sm-fill h3 my-2">
                Order No : <?php echo e($Model_Data->order_no); ?>

            </h1>
        </div>
        <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
            <nav class="flex-sm-00-auto" aria-label="breadcrumb">
                <ol class="breadcrumb breadcrumb-alt">
                    <li class="breadcrumb-item">
                        <a class="link-fx" href="<?php echo e(route('dashboard')); ?>">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a class="link-fx" href="<?php echo e(route('orders.index')); ?>">Orders</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">View Details</li>
                </ol>
            </nav>
            <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-dark btn-return pull-right">
                <i class="fa fa-chevron-left mr-2"></i> Return to Listing
            </a>
        </div>
        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<div class="content">
    <div class="row">
        <div class="col-sm-6">
            
            <div class="block block-rounded block-themed">
                <div class="block-header">
                    <h3 class="block-title">Order Details</h3>
                </div>
                <div class="block-content">
                    <?php echo $__env->make('restaurants.orders.order_fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            
            <div class="block block-rounded block-themed">
                <div class="block-header">
                    <h3 class="block-title">User Information</h3>
                </div>
                <div class="block-content">
                    <?php echo $__env->make('restaurants.orders.show_user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>

        <div class="col-sm-6">
            
            <div class="block block-rounded block-themed">
                <div class="block-header">
                    <h3 class="block-title">Ordered Items & Addons</h3>
                </div>
                <div class="block-content">
                    <a class="btn btn-dark text-white" target="_blank" href="<?php echo e(route('make-order-pdf',['id'=>$Model_Data->id])); ?>">
                        Print Invoice
                    </a>
                    <div class="col-sm-12 order_no incoming_order" id="<?php echo e($orders_common_details['id']); ?>" data-lastid="<?php echo e($orders_common_details['id']); ?>" data-lat="<?php echo e($orders_common_details['lat']); ?>" data-lng="<?php echo e($orders_common_details['lng']); ?>">            
                        <?php echo get_common_details_html($orders_common_details); ?>            
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="full_screen_modal" class="modal fade" data-backdrop="true">
    <div class="modal-dialog" id="full_screen_animate" style="max-width: 900px;">
        <div class="modal-content ordr_col">
            <div class="row m0 p0">
                <div class="col-sm-10 full_screen_order" id="full_screen_order"></div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<link rel="stylesheet" href="<?php echo e(asset_url('tooltip.min.css')); ?>">
<?php $__env->stopPush(); ?>


<?php $__env->startPush('scripts'); ?>
<script>

    jQuery(document).ready(function(e)
    {
        call_events();
    });

    function call_events()
    {
        $('[data-toggle="tooltip"]').tooltip();

        if($('.order_fullscreen'))
        {
            $('.order_fullscreen').off();
            $('.order_fullscreen').click(function(e) {
                var order_id = $(this).parent().parent().parent().data('lastid');
                full_screen_order(order_id);
            });
        }
    }

    function full_screen_order(order_id)
    {
        var div = $("#"+order_id);
        div_html = div.html();
        $("#full_screen_order").html(div_html);
        $("#full_screen_order").find( ".nomodal" ).remove();
        $("#full_screen_order").find( ".inmodal" ).removeClass('hide');
    }

</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/logicva1/sub_demos/sufra_v2/resources/views/restaurants/orders/show.blade.php ENDPATH**/ ?>