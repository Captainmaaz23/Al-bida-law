<!doctype html>
<html lang="<?php echo e(config('app.locale')); ?>">
    <head>
        <?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <?php echo $__env->yieldContent('headerInclude'); ?>
    </head>
    <body>
        <?php
        $container_class = "sidebar-o enable-page-overlay side-scroll page-header-fixed main-content-narrow";
        if (Auth::user()) {
            $header = Auth::user()->header;
            $sidebar = Auth::user()->sidebar;

            if ($header == 'dark' && $sidebar == 'dark')
                $container_class .= " page-header-dark sidebar-dark";
            elseif ($header == 'dark')
                $container_class .= " page-header-dark";
            elseif ($sidebar == 'dark')
                $container_class .= " sidebar-dark";
        }
        ?>

        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->make('layouts.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('footerInclude'); ?>

    </body>
</html><?php /**PATH /home2/logicva1/sub_demos/sufra_v2/resources/views/layouts/k_app.blade.php ENDPATH**/ ?>