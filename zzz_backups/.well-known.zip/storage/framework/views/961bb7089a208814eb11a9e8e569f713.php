

<?php $__env->startSection('content'); ?>
<?php
$AUTH_USER = Auth::user();
?>
<div class="bg-body-light">
    <div class="content">
        <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
            <h1 class="flex-sm-fill h3 my-2">Menus</h1>
        </div>
        <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
            <nav class="flex-sm-00-auto" aria-label="breadcrumb">
                <ol class="breadcrumb breadcrumb-alt">
                    <li class="breadcrumb-item">
                        <a class="link-fx" href="<?php echo e(route('dashboard')); ?>">Home</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Menus</li>
                </ol>
            </nav>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('menus-add')): ?>
                <a href="<?php echo e(route('menus.create')); ?>" class="btn btn-primary btn-add-new pull-right">
                    <i class="fa fa-plus-square fa-lg"></i> Add New
                </a>
            <?php endif; ?>
        </div>
        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<div class="content">
    <div class="block block-rounded block-themed">
        <div class="block-content">
            <?php if($recordsExists): ?>
                <?php if($AUTH_USER->rest_id > 0 && $menus->isNotEmpty()): ?>
                    <div class="row mt-2">
                        <div class="col-sm-12">
                            <a href="#" class="btn btn-primary pull-right" data-toggle="modal" data-target="#menuOrderModal">
                                Change Order
                            </a>

                            <div class="modal" id="menuOrderModal" tabindex="-1" role="dialog" aria-labelledby="menuOrderModal" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                                    <div class="modal-content">
                                        <div class="block block-rounded block-themed mb-0">
                                            <div class="block-header block-header-default">
                                                <h3 class="block-title">Edit Menus Order</h3>
                                                <div class="block-options">
                                                    <button type="button" class="btn-block-option btn_close_modal" data-bs-dismiss="modal" aria-label="Close">
                                                        <i class="fa fa-fw fa-times"></i>
                                                    </button>
                                                </div>
                                            </div>
                                            <div class="row mt-4">
                                                <div class="col-lg-1">&nbsp;</div>
                                                <div class="col-lg-10">
                                                    <form action="<?php echo e(route('restaurants_menus.order', $AUTH_USER->rest_id)); ?>" method="POST">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="table-responsive">
                                                            <table class="table table-striped table-hover">
                                                                <thead>
                                                                    <tr class="heading">
                                                                        <th>#</th>
                                                                        <th>Menus</th>
                                                                    </tr>
                                                                </thead>
                                                                <tbody>
                                                                    <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <tr>
                                                                            <td>
                                                                                <span class="ui-icon ui-icon-arrowthick-2-n-s"></span>
                                                                                <span class="spncount"><?php echo e($index + 1); ?></span>
                                                                                <input type="hidden" name="menu_order[]" value="<?php echo e($menu->id); ?>" />
                                                                            </td>
                                                                            <td><?php echo e($menu->title); ?></td>
                                                                        </tr>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </tbody>
                                                            </table>
                                                        </div>

                                                        <div class="mt-4 mb-3 row">
                                                            <div class="col-sm-12"><hr /></div>
                                                            <div class="form-group col-sm-12 text-right">
                                                                <button type="submit" class="btn btn-primary">Save Order</button>
                                                                <a href="<?php echo e(route('restaurants.index')); ?>" class="btn btn-outline-dark">Cancel</a>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                                <div class="col-lg-1">&nbsp;</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <form method="post" role="form" id="data-search-form">
                    <div class="table-responsive">
                        <table class="table table-striped table-hover" id="myDataTable">
                            <thead>
                                <tr class="heading">
                                    <?php if($AUTH_USER->rest_id == 0): ?>
                                        <td>
                                            <select class="form-control js-select2 form-select" id="s_rest_id">
                                                <option value="-1">Select</option>
                                                <?php $__currentLoopData = $restaurants_array; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </td>
                                        <td>
                                            <input type="text" class="form-control" id="s_title" autocomplete="off" placeholder="Title">
                                        </td>
                                        <td>
                                            <select class="form-control" id="s_availability">
                                                <option value="-1">Select</option>
                                                <option value="1">Available</option>
                                                <option value="0">Not Available</option>
                                            </select>
                                        </td>
                                        <td>
                                            <select class="form-control" id="s_status">
                                                <option value="-1">Select</option>
                                                <option value="1">Active</option>
                                                <option value="0">Inactive</option>
                                            </select>
                                        </td>
                                    <?php else: ?>
                                        <td>
                                            <input type="text" class="form-control" id="s_title" autocomplete="off" placeholder="Title">
                                        </td>
                                        <td>
                                            <select class="form-control" id="s_availability">
                                                <option value="-1">Select</option>
                                                <option value="1">Available</option>
                                                <option value="0">Not Available</option>
                                            </select>
                                        </td>
                                        <td>
                                            <select class="form-control" id="s_status">
                                                <option value="-1">Select</option>
                                                <option value="1">Active</option>
                                                <option value="0">Inactive</option>
                                            </select>
                                        </td>
                                    <?php endif; ?>
                                    <td>&nbsp;</td>
                                </tr>
                                <tr class="heading">
                                    <?php if($AUTH_USER->rest_id == 0): ?>
                                    <th>Restaurants</th>
                                    <?php endif; ?>
                                    <th>Title</th>
                                    <th>Availability</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </form>
            <?php else: ?>
                <p class="text-center font-weight-bold py-5">No Records Available</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php if($recordsExists): ?>
<?php $__env->startSection('headerInclude'); ?>
<?php echo $__env->make('datatables.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footerInclude'); ?>
<?php echo $__env->make('datatables.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startPush('scripts'); ?> 
<script>
    $(document).ready(function() {
        const oTable = $('#myDataTable').DataTable({
            processing: true,
            serverSide: true,
            stateSave: true,
            searching: false,
            dom: 'Blfrtip',
            autoWidth: false,
            buttons: [
                { extend: 'excel', exportOptions: { columns: ':visible' }},
                { extend: 'pdf', exportOptions: { columns: ':visible' }},
                { extend: 'print', exportOptions: { columns: ':visible' }},
                'colvis'
            ],
            ajax: {
                url: "<?php echo route('menus_datatable'); ?>",
                data: function(d) {
                    //d.rest_id = $('#s_rest_id').val();
                    d.title = $('#s_title').val();
                    d.availability = $('#s_availability').val();
                    d.status = $('#s_status').val();
                }
            },
            columns: [
                //{data: 'rest_id', name: 'rest_id'},
                {data: 'title', name: 'title'},
                {data: 'availability', name: 'availability'},
                {data: 'status', name: 'status'},
                {data: 'action', name: 'action'}
            ]
        });

        $('#data-search-form').on('submit', function(e) {
            e.preventDefault();
            oTable.draw();
        });

        $('#s_title, #s_rest_id, #s_availability, #s_status').on('change keyup', function(e) {
            oTable.draw();
        });
    });
</script>

<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<style>
    .menyTable-container table {
        border-spacing: 0;
    }
    .menyTable-container td {
        height: 25px;
        border: 1px solid black;
    }
    .ui-draggable, .ui-droppable {
        background-color: #F1F1F1;
        opacity: 1 !important;
    }
</style>
<script>
    $(document).ready(function(e) {
        $( "tbody" ).sortable(
            {
                update: function() {
                    slide_count();
                }
            });
    });

    function slide_count()
    {
        var btncount = 0;
        jQuery('.spncount').each(function(index, element) {
            var value = index;
            value++;
            $(this).html(value);
        });
    }
</script> 
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/logicva1/sub_demos/sufra_v2/resources/views/restaurants/menus/listing.blade.php ENDPATH**/ ?>