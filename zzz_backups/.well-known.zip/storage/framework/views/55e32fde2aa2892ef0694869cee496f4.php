

<?php $__env->startSection('content'); ?>

<div class="bg-body-light">
    <div class="content">
        <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
            <h1 class="flex-sm-fill h3 my-2">Edit Details</h1>
        </div>
        <div class="d-flex flex-column flex-sm-row justify-content-sm-between align-items-sm-center">
            <nav class="flex-sm-00-auto" aria-label="breadcrumb">
                <ol class="breadcrumb breadcrumb-alt">
                    <li class="breadcrumb-item">
                        <a class="link-fx" href="<?php echo e(route('dashboard')); ?>">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a class="link-fx" href="<?php echo e(route('general-settings.index')); ?>">General Settings</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Edit Details</li>
                </ol>
            </nav>
            <a href="<?php echo e(route('general-settings.index')); ?>" class="btn btn-dark btn-return pull-right">
                <i class="fa fa-chevron-left mr-2"></i> Return to Listing
            </a>
        </div>
        <?php echo $__env->make('flash::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<div class="content">                
    <div class="block block-rounded block-themed">
        <div class="block-header">
            <h3 class="block-title">Edit Details</h3>
        </div>
        <div class="block-content">
            <form action="<?php echo e(route('general_settings_update_Settings')); ?>" method="POST" enctype="multipart/form-data" name="myForm" id="myForm">
                <?php echo csrf_field(); ?>
                
                <?php echo $__env->make('general_settings.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>
    </div>                    
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home2/logicva1/sub_demos/sufra_v2/resources/views/general_settings/edit.blade.php ENDPATH**/ ?>