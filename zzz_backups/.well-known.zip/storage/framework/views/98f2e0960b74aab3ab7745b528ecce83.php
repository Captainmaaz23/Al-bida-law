<script src="<?php echo e(asset_url('/js/oneui.app.js')); ?>"></script>
<?php /* ?><script src="{{ url('/public/js/laravel.app.js') }}"></script>-->



<!-- Laravel Scaffolding JS -->
  <!-- <script src="{{mix('/js/laravel.app.js') }}"></script> --><?php */ ?>

<?php echo $__env->yieldContent('js_after'); ?>
<?php echo $__env->yieldPushContent('scripts'); ?><?php /**PATH /home2/logicva1/sub_demos/sufra_v2/resources/views/layouts/foot.blade.php ENDPATH**/ ?>