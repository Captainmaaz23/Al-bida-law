<?php
$AUTH_USER = Auth::user();
?>

<nav id="sidebar" aria-label="Main Navigation">
    <div class="content-header bg-white-5">
        <a class="font-w600 text-dual" href="<?php echo e(url('/dashboard')); ?>">
            <span class="smini-visible">
                <i class="fa fa-circle-notch text-primary"></i>
            </span>
            <span class="smini-hide font-size-h5 tracking-wider">
                <?php echo e(env('APP_NAME', 'Sufra')); ?>

            </span>
        </a>

        <div>
            <div class="dropdown d-inline-block ml-2">
                <a class="btn btn-sm btn-dual" id="sidebar-themes-dropdown" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="#">
                    <i class="si si-drop"></i>
                </a>
                <div class="dropdown-menu dropdown-menu-right font-size-sm smini-hide border-0" aria-labelledby="sidebar-themes-dropdown">
                    <?php $__currentLoopData = ['default', 'amethyst', 'city', 'flat', 'modern', 'smooth']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="dropdown-item d-flex align-items-center justify-content-between font-w500" href="<?php echo e(url('/users/' . $theme . '/set-theme')); ?>">
                            <span><?php echo e(ucfirst($theme)); ?></span>
                            <i class="fa fa-circle text-<?php echo e($theme); ?>"></i>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="dropdown-divider"></div>

                    <a class="dropdown-item font-w500" href="<?php echo e(url('/users/light/set-sidebar')); ?>">
                        <span>Sidebar Light</span>
                    </a>
                    <a class="dropdown-item font-w500" href="<?php echo e(url('/users/dark/set-sidebar')); ?>">
                        <span>Sidebar Dark</span>
                    </a>

                    <div class="dropdown-divider"></div>

                    <a class="dropdown-item font-w500" href="<?php echo e(url('/users/light/set-header')); ?>">
                        <span>Header Light</span>
                    </a>
                    <a class="dropdown-item font-w500" href="<?php echo e(url('/users/dark/set-header')); ?>">
                        <span>Header Dark</span>
                    </a>
                </div>
            </div>

            <a class="d-lg-none btn btn-sm btn-dual ml-1" data-toggle="layout" data-action="sidebar_close" href="javascript:void(0)">
                <i class="fa fa-fw fa-times"></i>
            </a>
        </div>
    </div>

    <div class="js-sidebar-scroll">                
        <div class="content-side">
            <ul class="nav-main">
                <li class="nav-main-item">
                    <a class="nav-main-link <?php echo e(request()->is('dashboard') ? 'active' : ''); ?>" href="<?php echo e(url('/dashboard')); ?>">
                        <i class="nav-main-link-icon si si-layers"></i>
                        <span class="nav-main-link-name">Dashboard</span>
                    </a>
                </li>
                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['orders-listing', 'all'])): ?>
                <li class="nav-main-item">
                    <a class="nav-main-link <?php echo e(request()->is('kitchen/dashboard') ? 'active' : ''); ?>" href="<?php echo e(url('/kitchen/dashboard')); ?>">
                        <i class="nav-main-link-icon si si-layers"></i>
                        <span class="nav-main-link-name">Kitchen</span>
                    </a>
                </li>

                <li class="nav-main-item <?php echo e(request()->is('orders/active-listing') || request()->is('orders/inactive-listing') || request()->is('orders*') ? 'open' : ''); ?>">
                    <a class="nav-main-link nav-main-link-submenu" data-toggle="submenu" aria-haspopup="true" aria-expanded="<?php echo e(request()->is('orders/active-listing') || request()->is('orders/inactive-listing') || request()->is('orders*') ? 'true' : 'false'); ?>" href="#">
                        <i class="nav-main-link-icon si si-social-dropbox"></i>
                        <span class="nav-main-link-name">Orders</span>
                    </a>
                    <ul class="nav-main-submenu">
                        <li class="nav-main-item">
                            <a class="nav-main-link <?php echo e(request()->is('orders/open-listing') ? 'active' : ''); ?>" href="<?php echo e(url('/orders/open-listing')); ?>">
                                <span class="nav-main-link-name">Open Orders</span>
                            </a>
                        </li>
                        <li class="nav-main-item">
                            <a class="nav-main-link <?php echo e(request()->is('orders/completed-listing') ? 'active' : ''); ?>" href="<?php echo e(url('/orders/completed-listing')); ?>">
                                <span class="nav-main-link-name">Completed Orders</span>
                            </a>
                        </li>
                        <li class="nav-main-item">
                            <a class="nav-main-link <?php echo e(request()->is('orders/declined-listing') ? 'active' : ''); ?>" href="<?php echo e(url('/orders/declined-listing')); ?>">
                                <span class="nav-main-link-name">Declined Orders</span>
                            </a>
                        </li>
                        <li class="nav-main-item">
                            <a class="nav-main-link <?php echo e(request()->is('orders/cancelled-listing') ? 'active' : ''); ?>" href="<?php echo e(url('/orders/cancelled-listing')); ?>">
                                <span class="nav-main-link-name">Cancelled Orders</span>
                            </a>
                        </li>  
                        <li class="nav-main-item">
                            <a class="nav-main-link <?php echo e(request()->is('orders*') ? 'active' : ''); ?>" href="<?php echo e(url('/orders')); ?>">
                                <span class="nav-main-link-name">All Orders</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['menus-listing', 'all'])): ?>
                <li class="nav-main-item <?php echo e(request()->is('menus/active-listing') || request()->is('menus/inactive-listing') || request()->is('menus*') ? 'open' : ''); ?>">
                    <a class="nav-main-link nav-main-link-submenu" data-toggle="submenu" aria-haspopup="true" aria-expanded="<?php echo e(request()->is('menus/active-listing') || request()->is('menus/inactive-listing') || request()->is('menus*') ? 'true' : 'false'); ?>" href="#">
                        <i class="nav-main-link-icon si si-social-dropbox"></i>
                        <span class="nav-main-link-name">Menus</span>
                    </a>
                    <ul class="nav-main-submenu">
                        <li class="nav-main-item">
                            <a class="nav-main-link <?php echo e(request()->is('menus/active-listing') ? 'active' : ''); ?>" href="<?php echo e(url('/menus/active-listing')); ?>">
                                <span class="nav-main-link-name">Active Menus</span>
                            </a>
                        </li>
                        <li class="nav-main-item">
                            <a class="nav-main-link <?php echo e(request()->is('menus/inactive-listing') ? 'active' : ''); ?>" href="<?php echo e(url('/menus/inactive-listing')); ?>">
                                <span class="nav-main-link-name">InActive Menus</span>
                            </a>
                        </li>  
                        <li class="nav-main-item">
                            <a class="nav-main-link <?php echo e(request()->is('menus*') ? 'active' : ''); ?>" href="<?php echo e(url('/menus')); ?>">
                                <span class="nav-main-link-name">All Menus</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['items-listing', 'all'])): ?>
                <li class="nav-main-item <?php echo e(request()->is('items/active-listing') || request()->is('items/inactive-listing') || request()->is('items*') ? 'open' : ''); ?>">
                    <a class="nav-main-link nav-main-link-submenu" data-toggle="submenu" aria-haspopup="true" aria-expanded="<?php echo e(request()->is('items/active-listing') || request()->is('items/inactive-listing') || request()->is('items*') ? 'true' : 'false'); ?>" href="#">
                        <i class="nav-main-link-icon si si-social-dropbox"></i>
                        <span class="nav-main-link-name">Items</span>
                    </a>
                    <ul class="nav-main-submenu">
                        <li class="nav-main-item">
                            <a class="nav-main-link <?php echo e(request()->is('items/active-listing') ? 'active' : ''); ?>" href="<?php echo e(url('/items/active-listing')); ?>">
                                <span class="nav-main-link-name">Active Items</span>
                            </a>
                        </li>
                        <li class="nav-main-item">
                            <a class="nav-main-link <?php echo e(request()->is('items/inactive-listing') ? 'active' : ''); ?>" href="<?php echo e(url('/items/inactive-listing')); ?>">
                                <span class="nav-main-link-name">InActive Items</span>
                            </a>
                        </li>  
                        <li class="nav-main-item">
                            <a class="nav-main-link <?php echo e(request()->is('items*') ? 'active' : ''); ?>" href="<?php echo e(url('/items')); ?>">
                                <span class="nav-main-link-name">All Items</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['serve-tables-listing', 'all'])): ?>
                <li class="nav-main-item <?php echo e(request()->is('serve-tables/active-listing') || request()->is('serve-tables/inactive-listing') || request()->is('serve-tables*') ? 'open' : ''); ?>">
                    <a class="nav-main-link nav-main-link-submenu" data-toggle="submenu" aria-haspopup="true" aria-expanded="<?php echo e(request()->is('serve-tables/active-listing') || request()->is('serve-tables/inactive-listing') || request()->is('serve-tables*') ? 'true' : 'false'); ?>" href="#">
                        <i class="nav-main-link-icon si si-social-dropbox"></i>
                        <span class="nav-main-link-name">Tables</span>
                    </a>
                    <ul class="nav-main-submenu">
                        <li class="nav-main-item">
                            <a class="nav-main-link <?php echo e(request()->is('serve-tables/active-listing') ? 'active' : ''); ?>" href="<?php echo e(url('/serve-tables/active-listing')); ?>">
                                <span class="nav-main-link-name">Active Tables</span>
                            </a>
                        </li>
                        <li class="nav-main-item">
                            <a class="nav-main-link <?php echo e(request()->is('serve-tables/inactive-listing') ? 'active' : ''); ?>" href="<?php echo e(url('/serve-tables/inactive-listing')); ?>">
                                <span class="nav-main-link-name">InActive Tables</span>
                            </a>
                        </li>  
                        <li class="nav-main-item">
                            <a class="nav-main-link <?php echo e(request()->is('serve-tables*') ? 'active' : ''); ?>" href="<?php echo e(url('/serve-tables')); ?>">
                                <span class="nav-main-link-name">All Tables</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>
                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['app-users-listing', 'all'])): ?>
                <li class="nav-main-item <?php echo e(request()->is('app-users/active-listing') || request()->is('app-users/inactive-listing') || request()->is('app-users*') ? 'open' : ''); ?>">
                    <a class="nav-main-link nav-main-link-submenu" data-toggle="submenu" aria-haspopup="true" aria-expanded="<?php echo e(request()->is('app-users/active-listing') || request()->is('app-users/inactive-listing') || request()->is('app-users*') ? 'true' : 'false'); ?>" href="#">
                        <i class="nav-main-link-icon si si-social-dropbox"></i>
                        <span class="nav-main-link-name">App Users</span>
                    </a>
                    <ul class="nav-main-submenu">
                        <li class="nav-main-item">
                            <a class="nav-main-link <?php echo e(request()->is('app-users/active-listing') ? 'active' : ''); ?>" href="<?php echo e(url('/app-users/active-listing')); ?>">
                                <span class="nav-main-link-name">Active App Users</span>
                            </a>
                        </li>
                        <li class="nav-main-item">
                            <a class="nav-main-link <?php echo e(request()->is('app-users/inactive-listing') ? 'active' : ''); ?>" href="<?php echo e(url('/app-users/inactive-listing')); ?>">
                                <span class="nav-main-link-name">InActive App Users</span>
                            </a>
                        </li>  
                        <li class="nav-main-item">
                            <a class="nav-main-link <?php echo e(request()->is('app-users*') ? 'active' : ''); ?>" href="<?php echo e(url('/app-users')); ?>">
                                <span class="nav-main-link-name">All App Users</span>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['users-listing', 'all'])): ?>
                <li class="nav-main-item <?php echo e(request()->is('users/active-listing') || request()->is('users/inactive-listing') || request()->is('users*') ? 'open' : ''); ?>">
                    <a class="nav-main-link nav-main-link-submenu" data-toggle="submenu" aria-haspopup="true" aria-expanded="<?php echo e(request()->is('users/active-listing') || request()->is('users/inactive-listing') || request()->is('users*') ? 'true' : 'false'); ?>" href="#">
                        <i class="nav-main-link-icon si si-users"></i>
                        <span class="nav-main-link-name">Users</span>
                    </a>
                    <ul class="nav-main-submenu">  
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('users-listing')): ?>
                        <li class="nav-main-item">
                            <a class="nav-main-link <?php echo e(request()->is('users/active-listing') ? 'active' : ''); ?>" href="<?php echo e(url('/users/active-listing')); ?>">
                                <span class="nav-main-link-name">Active Users</span>
                            </a>
                        </li>
                        <li class="nav-main-item">
                            <a class="nav-main-link <?php echo e(request()->is('users/inactive-listing') ? 'active' : ''); ?>" href="<?php echo e(url('/users/inactive-listing')); ?>">
                                <span class="nav-main-link-name">InActive Users</span>
                            </a>
                        </li>
                        <li class="nav-main-item">
                            <a class="nav-main-link <?php echo e(request()->is('users*') ? 'active' : ''); ?>" href="<?php echo e(url('/users')); ?>">
                                <span class="nav-main-link-name">All Users</span>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['roles-listing', 'general-settings-listing', 'addon-types-listing', 'all'])): ?>
                <li class="nav-main-item <?php echo e(request()->is('roles*') || request()->is('general-settings*') || request()->is('addon-types*') ? 'open' : ''); ?>">
                    <a class="nav-main-link nav-main-link-submenu" data-toggle="submenu" aria-haspopup="true" aria-expanded="<?php echo e(request()->is('roles*') || request()->is('general-settings*') || request()->is('addon-types*') ? 'true' : 'false'); ?>" href="#">
                        <i class="nav-main-link-icon si si-social-dropbox"></i>
                        <span class="nav-main-link-name">Settings</span>
                    </a>
                    <ul class="nav-main-submenu">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('roles-listing')): ?>
                        <li class="nav-main-item">
                            <a class="nav-main-link <?php echo e(request()->is('roles*') ? 'active' : ''); ?>" href="<?php echo e(url('/roles')); ?>">
                                <span class="nav-main-link-name">Roles</span>
                            </a>
                        </li>
                        <?php endif; ?>  
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('general-settings-listing')): ?>
                        <li class="nav-main-item">
                            <a class="nav-main-link <?php echo e(request()->is('general-settings*') ? 'active' : ''); ?>" href="<?php echo e(url('/general-settings')); ?>">
                                <span class="nav-main-link-name">General</span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('addon-types-listing')): ?>
                        <li class="nav-main-item">
                            <a class="nav-main-link <?php echo e(request()->is('addon-types*') ? 'active' : ''); ?>" href="<?php echo e(url('/addon-types')); ?>">
                                <span class="nav-main-link-name">Addon Types</span>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['all'])): ?>
                <li class="nav-main-item">
                    <a class="nav-main-link" href="<?php echo e(url('/kitchen/clear_pending_orders')); ?>">
                        <i class="nav-main-link-icon si si-layers"></i>
                        <span class="nav-main-link-name">Clear Pending Orders</span>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH /home2/logicva1/sub_demos/sufra_v2/resources/views/layouts/sidebar.blade.php ENDPATH**/ ?>