<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Api\ApiBaseController as BaseController;
use Illuminate\Http\Request;

class ApiCronJobController extends BaseController {

    public function retMethod(Request $request, $action = 'listing') {
        if ($action === 'listing') {
            return $this->listing();
        }
    }

    public function listing() {
        update_order_status_automatically();
        serve_tables_availability_automatically();
        menus_availability_automatically();
        items_availability_automatically();
    }
}
