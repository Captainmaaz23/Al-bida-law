<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Api\ApiBaseController as BaseController;
use App\Models\Order;
use App\Models\AppUser;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use Illuminate\Support\Str;

class ApiAuthController extends BaseController {

    private $_token = null;
    private $lat = null;
    private $lng = null;
    private $radius = 5;  // Default value for radius
    private $uploads_root = "uploads";
    private $uploads_path = "uploads/app_users";
    private $uploads_people = "uploads/app_user_people";

    public function retMethod(Request $request, $action = 'listing') {
        ((!empty($request->header('token'))) ? $this->_token = $request->header('token') : $this->_token = null);

        ((!empty($request->header('lat'))) ? $this->lat = $request->header('lat') : $this->lat = null);
        ((!empty($request->header('lng'))) ? $this->lng = $request->header('lng') : $this->lng = null);
        ((!empty($request->header('radius'))) ? $this->radius = $request->header('radius') : $this->radius = 5);

        $token = $this->_token;
        if (!empty($token)) {
            $Verifications = DB::table('verification_codes')->where('token', $token)->where('expired', 1)->first();
            if (empty($Verifications)) {
                $response = [
                    'code'    => '201',
                    'status'  => false,
                    'token'   => $token,
                    'data'    => null,
                    'message' => 'Incorrect Token!',
                ];
                return response()->json($response, 200);
            }
            elseif ($action == 'update-location-data') {
                update_app_user_location_data($this->_token, $this->lat, $this->lng);
                $response = [
                    'code'    => '201',
                    'status'  => true,
                    'data'    => null,
                    'message' => 'Updated User Location data successfully!',
                ];
                return response()->json($response, 200);
            }
            elseif ($action == 'token-validate') {
                $response = [
                    'code'    => '201',
                    'status'  => true,
                    'data'    => null,
                    'message' => 'Valid Token!',
                ];
                return response()->json($response, 200);
            }
            elseif ($action == 'token-expire') {

                $user_id = $Verifications->user_id;

                DB::table('verification_codes')->where('user_id', $user_id)->update([
                    'expired'    => 0,
                    'updated_at' => now()
                ]);

                $response = [
                    'code'    => '201',
                    'status'  => true,
                    'data'    => null,
                    'message' => 'Session Expired Successfully!',
                ];
                return response()->json($response, 200);
            }
        }

        if (!empty($request->header('token')) && !empty($request->header('lat')) && !empty($request->header('lng'))) {
            update_app_user_location_data($this->_token, $this->lat, $this->lng);
        }

        $page = 1;
        $limit = 10;
        (isset($request->page) ? $page = trim($request->page) : 1);
        (isset($request->limit) ? $limit = trim($request->limit) : 10);

        if ($action == 'login') {
            return $this->loginEmail($request);
        }
        elseif (!empty($request->header('token'))) {
            $token = $request->header('token');

            if (!empty($token)) {
                $Verifications = DB::table('verification_codes')->where('token', $token)->where('expired', 1)->first();

                if (empty($Verifications)) {

                    $response = [
                        'code'    => '201',
                        'status'  => false,
                        'token'   => $token,
                        'data'    => null,
                        'message' => 'Incorrect Token!',
                    ];
                    return response()->json($response, 200);
                }

                $user_id = $Verifications->user_id;

                $User = AppUser::where('id', $user_id)->first();

                if (empty($User) || $User->status == 0) {

                    return $this->sendError('User Not Found!');
                }

                switch ($action) {
                    case 'listing-orders': {
                            return $this->orderListing($request, $User, $page, $limit);
                        }
                        break;

                    case 'listing-orders-today': {
                            return $this->orderListingToday($request, $User, $page, $limit);
                        }
                        break;

                    case 'listing-orders-open': {
                            return $this->orderListingOpen($request, $User, $page, $limit);
                        }
                        break;

                    case 'details-order': {
                            return $this->orderDetails($request, $User);
                        }
                        break;

                    case 'status-order': {
                            return $this->orderStatus($request, $User);
                        }
                        break;

                    case 'cancel-order': {
                            return $this->orderCancel($request, $User);
                        }
                        break;

                    case 'collect-order': {
                            return $this->orderCollect($request, $User);
                        }
                        break;

                    case 'orderCounts': {
                            return $this->orderCounts($request, $User);
                        }
                        break;

                    default: {
                            return $this->sendError('Invalid Request');
                        }
                        break;
                }
            }
            else {
                return $this->sendError('Invalid Access Token provided');
            }
        }
        else {
            return $this->sendError('You are not authorized.');
        }
    }

    public function loginEmail(Request $request) {
        $username = $request->input('username', '');
        $password = $request->input('password', '');

        if (empty($username) || empty($password)) {
            return $this->sendError("Missing Parameters");
        }

        // Check if the user exists
        $User = AppUser::where('username', '=', $username)->first();
        if (!$User || !Hash::check($password, $User->password)) {
            return $this->sendError('Login Failed, Incorrect Credentials Provided!');
        }

        // Generate the token
        $token = gen_random(9, 1) . '-' . gen_random(5, 2);

        // Store the verification code in the database
        DB::table('verification_codes')->insert([
            'user_id'      => $User->id,
            'type'         => 'email',
            'sent_to'      => $username,
            'code'         => '1234',
            'verified'     => 1,
            'token'        => $token,
            'expired'      => 1,
            'generated_at' => now(),
            'created_at'   => now(),
            'updated_at'   => now()
        ]);

        // Update device information
        $User->update([
            'device_name' => $request->device_name ?? null,
            'device_id'   => $request->device_id ?? null
        ]);

        // Prepare response data
        $array = get_user_array($User);

        return response()->json([
                    'code'    => '201',
                    'status'  => true,
                    'message' => 'User authenticated, successfully!',
                    'data'    => [
                        'token' => $token,
                        'user'  => $array
                    ]
                        ], 200);
    }

    // Create a reusable method for fetching orders
    private function getOrdersQuery($request, $user_id, $page, $limit, $status = null, $dateRange = false) {
        $skip = ($page - 1) * $limit;

        $query = Order::leftjoin('restaurants', 'orders.rest_id', '=', 'restaurants.id')
                ->leftjoin('serve_tables', 'orders.table_id', '=', 'serve_tables.id')
                ->leftjoin('app_users', 'orders.user_id', '=', 'app_users.id')
                ->where(['orders.user_id' => $user_id, 'restaurants.status' => 1]);

        // Apply filters conditionally using `when()`
        $query->when($request->table_id, function ($query) use ($request) {
            return $query->where('orders.table_id', $request->table_id);
        });

        if ($dateRange) {
            $today = Carbon::today();
            $query->where('orders.created_at', '>=', $today);
        }

        // Apply status filter if necessary
        if ($status) {
            $query->whereIn('orders.status', $status);
        }

        // Apply date filters
        $query->when($request->from_date, function ($query) use ($request) {
            $carbon_from_date = Carbon::parse($request->from_date . ' 00:00:00');
            return $query->where('orders.created_at', '>=', $carbon_from_date);
        });
        $query->when($request->to_date, function ($query) use ($request) {
            $carbon_to_date = Carbon::parse($request->to_date . ' 00:00:00')->addDay();
            return $query->where('orders.created_at', '<', $carbon_to_date);
        });

        $query->select(['orders.*', 'restaurants.name as rest_name', 
                    'serve_tables.title as table_name', 'serve_tables.icon as table_icon', 
                    'app_users.user_type as user_type', 'app_users.name as user_name', 'app_users.photo_type', 'app_users.photo as user_photo'
                    ])
            ->orderBy('orders.id', 'DESC')->skip($skip)->take($limit);
        //$sql = Str::replaceArray('?', $query->getBindings(), $query->toSql());dd($sql);
        return $query;
    }

    private function get_orderListing(Request $request, $User, $page = 1, $limit = 10) {
        $user_id = $User->id;
        $status = [9]; // Example: Only active orders (status 9)
        $Records = $this->getOrdersQuery($request, $user_id, $page, $limit, $status, false);
        return $Records;
    }

    public function orderListing(Request $request, $User, $page = 1, $limit = 10) {
        $Records = $this->get_orderListing($request, $User, $page, $limit);
        $count_all = $Records->count();
        return $this->prepareOrderListingResponse($Records, $count_all, $request, $page, $limit);
    }

    private function get_orderListingOpen(Request $request, $User, $page = 1, $limit = 10) {
        $user_id = $User->id;
        $status = [3, 5, 6, 7, 8]; // Open orders
        $Records = $this->getOrdersQuery($request, $user_id, $page, $limit, $status, false);
        return $Records;
    }

    public function orderListingOpen(Request $request, $User, $page = 1, $limit = 10) {        
        $Records = $this->get_orderListingOpen($request, $User, $page, $limit);
        $count_all = $Records->count();
        return $this->prepareOrderListingResponse($Records, $count_all, $request, $page, $limit);
    }

    private function get_orderListingToday(Request $request, $User, $page = 1, $limit = 10) {
        $user_id = $User->id;
        $status = [9]; // Active orders today
        $Records = $this->getOrdersQuery($request, $user_id, $page, $limit, $status, true);
        return $Records;
    }

    public function orderListingToday(Request $request, $User, $page = 1, $limit = 10) {
        $Records = $this->get_orderListingToday($request, $User, $page, $limit);
        $count_all = $Records->count();
        return $this->prepareOrderListingResponse($Records, $count_all, $request, $page, $limit);
    }

    private function prepareOrderListingResponse($Records, $count_all, $request, $page, $limit) {
        $orders = null;
        $message = 'No Record Found.';

        if ($Records->count() > 0) {
            $array_data = orders_data($Records, $this->_token, $this->lat, $this->lng);
            if (!empty($array_data)) {
                $orders = $array_data;
                $message = 'All User Orders Listing retrieved successfully.';
            }
        }

        $data = [
            'table_id'    => (int)$request->table_id ?? '',
            'from_date'   => $request->from_date ?? '',
            'to_date'     => $request->to_date ?? '',
            'status'      => $request->status ?? '',
            'page'        => (int)$page,
            'limit'       => (int)$limit,
            'page_count'  => (int)$Records->count(),
            'total_count' => (int)$count_all,
            'data'        => $orders,
        ];

        return response()->json([
                    'code'    => '201',
                    'status'  => true,
                    'data'    => $data,
                    'message' => $message,
                        ], 200);
    }

    public function orderDetails(Request $request, $User) {
        $order_id = trim($request->order_id);
        $user_id = $User->id;

        $Record = Order::leftjoin('restaurants', 'orders.rest_id', '=', 'restaurants.id')
                ->where(['orders.id' => $order_id, 'orders.user_id' => $user_id, 'restaurants.status' => 1])
                ->select(['orders.id'])
                ->first();

        if (!$Record) {
            return $this->sendError('Please provide valid order details.');
        }        

        $Record = commonOrderDetailQuery($order_id, $user_id);
        $Response = orders_details($Record, $this->_token, $this->lat, $this->lng);
        $message = 'Order Details Successfully retrieved';

        return response()->json([
                    'code'    => '201',
                    'status'  => true,
                    'data'    => $Response,
                    'message' => $message,
                        ], 200);
    }

    public function orderStatus(Request $request, $User) {
        $order_id = trim($request->order_id);
        $user_id = $User->id;

        $Record = Order::leftjoin('restaurants', 'orders.rest_id', '=', 'restaurants.id')
                ->where(['orders.id' => $order_id, 'orders.user_id' => $user_id, 'restaurants.status' => 1])
                ->select(['orders.id'])
                ->first();

        if (!$Record) {
            return $this->sendError('Please provide valid order details.');
        }

        $Record = Order::find($order_id)->toArray();
        $response_data = get_order_status($Record, $this->_token, $this->lat, $this->lng);
        $response_data = $response_data ?? [];
        $counts_data = $this->overall_order_count($request, $User);
        $response_data = array_merge($response_data, $counts_data);
        $message = 'Order Status Successfully retrieved';

        return response()->json([
                    'code'    => '201',
                    'status'  => true,
                    'data'    => $response_data,
                    'message' => $message,
                        ], 200);
    }

    public function orderCancel(Request $request, $User) {
        $id = $request->id ?? null;

        if (empty($id)) {
            return $this->sendError('Required parameters are missing!');
        }

        $user_id = $User->id;
        $cancel = false;

        $record = Order::leftJoin('restaurants', 'orders.rest_id', '=', 'restaurants.id')
                ->where(['orders.id' => $id, 'orders.user_id' => $user_id, 'restaurants.status' => 1])
                ->select('orders.status')
                ->first();

        if (!$record) {
            return $this->sendError('Record Not Found!');
        }

        if (in_array($record->status, [1, 3])) {
            $cancel = true;
        }

        $message = $cancel ? 'User Order canceled successfully.' : 'Order cannot be canceled.';
        if ($cancel) {
            $order = Order::find($id);
            $order->status = 2;
            $order->cancelled_time = time();
            $order->save();
        }
        
        $Record = commonOrderDetailQuery($id, $user_id);
        $response_data = $this->getOrderDetails($Record);  // Assuming this is a function to get order details.
        $response_data = $response_data ?? [];
        $counts_data = $this->overall_order_count($request, $User);
        $response_data = array_merge($response_data, $counts_data);

        return response()->json([
                    'code'    => '201',
                    'status'  => true,
                    'data'    => $response_data,
                    'message' => $message
                        ], 200);
    }

    public function orderCollect(Request $request, $User) {
        $ids = $request->id ?? null;

        if (empty($ids)) {
            return $this->sendError('Required parameters are missing!');
        }

        $user_id = $User->id;
        $order_ids = explode(',', $ids);

        $response_data = null;
        $message = 'Order Collected Successfully.';

        foreach ($order_ids as $id) {
            $order = Order::leftJoin('restaurants', 'orders.rest_id', '=', 'restaurants.id')
                    ->where(['orders.id' => $id, 'orders.user_id' => $user_id, 'orders.status' => 8, 'restaurants.status' => 1])
                    ->first();

            if ($order) {
                $order->collected_time = time();
                $order->status = 9;
                $order->save();
                $response_data = $this->getOrderDetails($order);
            }
        }
        $response_data = $response_data ?? [];
        $counts_data = $this->overall_order_count($request, $User);
        $response_data = array_merge($response_data, $counts_data);

        return response()->json([
                    'code'    => '201',
                    'status'  => true,
                    'data'    => $response_data,
                    'message' => $message
                        ], 200);
    }
    
    public function orderCounts(Request $request, $User){
        $id = $request->id ?? null;

        if (empty($id)) {
            return $this->sendError('Required parameters are missing!');
        }
        
        $counts_data = $this->overall_order_count($request, $User);
        $message = 'Order Counts Successfully.';

        return response()->json([
                    'code'    => '201',
                    'status'  => true,
                    'data'    => $response_data,
                    'message' => $message
                        ], 200);
    }
    
    private function overall_order_count($request, $User) {
        $all_history_count = $this->get_orderListing($request, $User)->count();      
        $open_history_count = $this->get_orderListingOpen($request, $User)->count();        
        $today_history_count = $this->get_orderListingToday($request, $User)->count();
        
        $data = [];
        $data['counts_data'] = [
            'all_history_count' => $all_history_count,
            'open_history_count' => $open_history_count,
            'today_history_count' => $today_history_count,
        ];
        return $data;
    }

    public function get_restaurant_array($record) {
        $rest_img_path = $record->profile == 'restaurant.png' ? 'defaults/' : 'restaurants/';
        $rest_img_path .= $record->profile;

        return [
            'id'             => $record->id,
            'name'           => $record->name,
            'ar_name'        => $record->arabic_name,
            'description'    => $record->description,
            'ar_description' => $record->arabic_description,
            'location'       => $record->location,
            'lat'            => $record->lat,
            'lng'            => $record->lng,
            'image'          => uploads($rest_img_path)
        ];
    }
}
