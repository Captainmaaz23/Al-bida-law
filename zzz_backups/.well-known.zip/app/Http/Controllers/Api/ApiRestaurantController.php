<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Api\ApiBaseController as BaseController;
use App\Models\Restaurant;
use App\Models\Order;
use App\Models\OrderDetail;
use App\Models\OrderSubDetail;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
//use App\Events\OrderPlaced;

class ApiRestaurantController extends BaseController {

    private $_token = null;
    private $lat = null;
    private $lng = null;
    private $radius = null;

    public function retMethod(Request $request, $action = 'listing') {
        // Token Handling
        $this->_token = $request->header('token') ?: null;

        if ($this->_token) {
            $Verifications = DB::table('verification_codes')->where('token', $this->_token)->where('expired', 1)->first();
            if (empty($Verifications)) {
                return response()->json([
                    'code'    => '201',
                    'status'  => false,
                    'token'   => $this->_token,
                    'data'    => null,
                    'message' => 'Incorrect Token!',
                        ], 200);
            }
        }

        // Location Data
        $this->lat = $request->header('lat') ?: null;
        $this->lng = $request->header('lng') ?: null;
        $this->radius = $request->header('radius') ?: 5;

        if ($this->_token && $this->lat && $this->lng) {
            update_app_user_location_data($this->_token, $this->lat, $this->lng);
        }

        // Pagination Defaults
        $page = $request->page ?: 1;
        $limit = $request->limit ?: 10;

        if (isset($request->id)) {
            $id = trim($request->id);
            if ($id) {
                $modelData = Restaurant::find($id);
                if (!$modelData || $modelData->status == 0) {
                    return $this->sendError('Restaurant Details not found.');
                }

                switch ($action) {
                    case 'menus':
                        return $this->menus($modelData);

                    case 'create-order':
                        if ($modelData->is_open == 0)
                            return $this->sendError('Restaurant is Closed.');
                        if ($this->_token) {
                            if (!isset($request->items))
                                return $this->sendError('Please Provide order details');
                            return $this->orderCreate($modelData, $request);
                        }
                        return $this->sendError('Please Login first to create orders');

                    case 'update-order':
                        if (!isset($request->order_id))
                            return $this->sendError('Please Provide order details');
                        if ($modelData->is_open == 0)
                            return $this->sendError('Restaurant is Closed.');
                        if ($this->_token) {
                            if (!isset($request->items))
                                return $this->sendError('Please Provide order details');
                            return $this->orderUpdate($modelData, $request);
                        }
                        return $this->sendError('Please Login first to create orders');

                    default:
                        return $this->sendError('Invalid Request');
                }
            }
            else {
                return $this->sendError('Please Provide Restaurant id in Request');
            }
        }

        if ($action == 'order-details' && isset($request->order_id)) {
            $order_id = trim($request->order_id);
            if ($order_id) {
                $Record = Order::find($order_id)->toArray();
                if ($Record) {
                    return response()->json([
                                'code'    => '201',
                                'status'  => true,
                                'data'    => orders_details($Record, $this->_token, $this->lat, $this->lng),
                                'message' => 'Order Details Successfully retrieved',
                                    ], 200);
                }
                return $this->sendError('Order Not Found. Please try valid order details');
            }
            return $this->sendError('Please provide order details.');
        }

        return $this->sendError('Invalid Request');
    }

    // Get Menus of Restaurant
    public function menus($modelData) {
        $id = $modelData->id;
        $Data = get_rest_menus($id);
        $Data_tables = get_rest_tables($id);

        $Data_Response = [
            'tables' => $Data_tables,
            'menus'  => $Data,
        ];

        $message = $Data ? 'Restaurant Menus Listing retrieved successfully.' : 'No Record Found.';

        $response = [
            'code'    => '201',
            'status'  => true,
            'data'    => $Data_Response,
            'message' => $message,
        ];

        return response()->json($response, 200);
    }

    // Get All Reviews of Restaurant
    public function reviews($modelData) {
        $id = $modelData->id;
        $Data = get_rest_reviews($id);

        $Response = [
            'id'      => $id,
            'reviews' => $Data,
        ];
        $message = $Data ? 'Restaurant Reviews retrieved successfully.' : 'No Record Found.';

        $response = [
            'code'    => '201',
            'status'  => true,
            'data'    => $Response,
            'message' => $message,
        ];
        return response()->json($response, 200);
    }

    public function orderCreate($modelData, $request) {
        $rest_id = $modelData->id;

        $user_id = $this->getUserId();
        $has_ongoing_order = $this->checkOngoingOrder($user_id);

        if ($has_ongoing_order == 0) {
            $order = $this->createOrder($request, $rest_id, $user_id);
            $order_id = $order->id;

            $order_no = $this->generateOrderNo($order_id);
            $order_value = 0;
            $items = $request->items;

            foreach ($items as $item) {
                $order_value += $this->processItem($item, $order_id);
            }

            $final_value = $this->calculateOrderTotal($order_value);
            $this->updateOrder($order, $order_no, $order_value, $final_value);

            //broadcast(new OrderPlaced($order));

            if ($order->pay_method == 'cash') {
                $order->status = 3;
                $this->updateOrderStatus($order_id, $order->status);
            }

            $response = [
                'code'    => '201',
                'status'  => true,
                'data'    => $this->getOrderDetails($order_id),
                'message' => 'Order Successfully saved',
            ];
        }
        else {
            $response = [
                'code'    => '400',
                'status'  => false,
                'data'    => null,
                'message' => 'You have an Ongoing Order. You cannot place another order.',
            ];
        }

        return response()->json($response, 200);
    }

    private function getUserId() {
        $User = getUser($this->_token);
        return $User ? $User->id : -1;
    }

    private function checkOngoingOrder($user_id) {
        /* {
          $Ongoing_orders = Order::where('user_id',$user_id)->where('status','>=',3)->where('status','<>',4)->where('status','<=',8)->get();
          foreach($Ongoing_orders as $order)
          {
          $has_ongoing_order = 1;
          }
          } */
        return 0;
    }

    private function createOrder($request, $rest_id, $user_id) {
        $order = new Order();
        $order->rest_id = $rest_id;
        $order->table_id = $request->table_id;
        $order->user_id = $user_id;
        $order->lat = $this->lat ?? 0;
        $order->lng = $this->lng ?? 0;
        $order->pickup_time = Carbon::now()->addMinutes(10);  // 10 minutes from now
        $order->pay_method = 'cash';
        $order->pay_method_id = 0;
        $order->pay_status = 0;
        $order->transaction_id = 0;
        $order->order_value = 0;
        $order->promo_id = 0;
        $order->promo_value = 0;
        $order->total_value = 0;
        $order->vat_included = 0;
        $order->vat_value = 0;
        $order->final_value = 0;
        $order->status = 1;
        $order->save();
        return $order;
    }

    private function generateOrderNo($order_id) {
        $day = sprintf('%02d', date('d', time()));
        $month = sprintf('%02d', date('m', time()));
        $year = date('y', time());
        $code = sprintf("%04u", $order_id);
        return $year . $month . $day . "-" . $code;
    }

    private function processItem($item, $order_id) {
        $notes = $item['notes'] ?? '';
        $item_id = $item['item_id'];
        $quantity = (float) $item['quantity'];
        $item_value = 0;
        $discount_value = 0;
        $total_value = 0;

        $item_details = get_items_prices_for_orders($item_id);
        if ($item_details) {
            $item_value = (float) $item_details['price'];
            $discount_value = $this->calculateDiscount($item_details, $item_value);
            $total_value = ($item_value - $discount_value);
        }

        $total_value *= $quantity;
        $total_value = round($total_value, 2);

        $this->saveOrderDetail($order_id, $item, $notes, $quantity, $item_value, $discount_value, $total_value);

        return $total_value;
    }

    private function calculateDiscount($item_details, $item_value) {
        $discount_value = 0;
        $discount = (float) $item_details['discount'];
        $discount_type = $item_details['discount_type'];

        if ($discount_type == 0) {
            $discount_value = round(($discount / 100) * $item_value, 2);
        }
        else {
            $discount_value = $discount;
        }

        return $discount_value;
    }

    private function saveOrderDetail($order_id, $item, $notes, $quantity, $item_value, $discount_value, $total_value) {
        $details = new OrderDetail();
        $details->order_id = $order_id;
        $details->item_id = $item['item_id'];
        $details->notes = $notes;
        $details->quantity = $quantity;
        $details->item_value = $item_value;
        $details->discount = $discount_value;
        $details->total_value = $total_value;
        $details->save();
    }

    private function calculateOrderTotal($order_value) {
        $total_order_value = $order_value;
        $vat_value = $this->calculateVat($total_order_value);
        $final_value = $total_order_value + $vat_value;
        $service_charges = $this->calculateServiceCharges($total_order_value);

        return $final_value + $service_charges;
    }

    private function calculateVat($total_order_value) {
        $vat_include = get_vat_value();
        if ($vat_include > 0) {
            return round(($vat_include / 100) * $total_order_value, 2);
        }
        return 0;
    }

    private function calculateServiceCharges($total_order_value) {
        $service_charges_include = get_vat_value();
        if ($service_charges_include > 0) {
            return round(($service_charges_include / 100) * $total_order_value, 2);
        }
        return 0;
    }

    private function updateOrder($order, $order_no, $order_value, $final_value) {
        $order->order_no = $order_no;
        $order->order_value = $order_value;
        $order->total_value = $order_value;
        $order->final_value = $final_value;
        $order->save();
    }

    private function updateOrderStatus($order_id, $status) {
        $order = Order::find($order_id);
        $order->status = $status;
        $order->confirmed_time = Carbon::now()->toDateTimeString();//time();
        $order->save();
    }

    private function getOrderDetails($order_id) {
        $order = Order::find($order_id)->toArray();
        return orders_details($order, $this->_token, $this->lat, $this->lng, true, false);
    }

    public function orderUpdate($modelData, $request) {
        if (!isset($request->order_id)) {
            return $this->sendError('Please Provide order details');
        }

        $req_order_id = $request->order_id;
        $rest_id = $modelData->id;
        $user_id = getUser($this->_token) ? getUser($this->_token)->id : -1;

        // Check if the user has an ongoing order
        $has_ongoing_order = Order::where('id', $req_order_id)
                ->where('user_id', $user_id)
                ->whereBetween('status', [3, 6])
                ->where('status', '<>', 4)
                ->exists();

        if ($has_ongoing_order) {
            $record = Order::find($req_order_id);
            $record->status = 2;  // Cancel the previous order
            $record->cancelled_time = Carbon::now()->toDateTimeString();//time();
            $record->save();

            // Initialize location data
            $lat = $this->lat ?? 0;
            $lng = $this->lng ?? 0;
            
            $order = $this->createOrder($request, $rest_id, $user_id);

            $order_id = $order->id;
            $order_no = sprintf("%02d%02d%02d-%04u", date('y'), date('m'), date('d'), $order_id);

            $order_value = 0;

            // Process each item in the order
            foreach ($request->items as $item) {
                $notes = $item['notes'] ?? '';
                $item_id = $item['item_id'];
                $quantity = (float) $item['quantity'];
                $item_details = get_items_prices_for_orders($item_id);

                $item_value = $item_details ? (float) $item_details['price'] : 0;
                $discount_value = $item_details ? $this->getDiscountValue($item_details['discount'], $item_details['discount_type'], $item_value) : 0;
                $total_value = ($item_value - $discount_value) * $quantity;

                $details = new OrderDetail();
                $details->order_id = $order_id;
                $details->item_id = $item_id;
                $details->notes = $notes;
                $details->quantity = $quantity;
                $details->item_value = $item_value;
                $details->discount = $discount_value;
                $details->total_value = $total_value;
                $details->save();

                $order_value += $total_value;

                // Process item addons
                if (isset($item['addons'])) {
                    foreach ($item['addons'] as $addon) {
                        $addon_id = $addon['id'];
                        $addon_details = get_addon_prices_for_orders($addon_id);
                        $addon_value = $addon_details ? $addon_details['price'] * $quantity : 0;

                        $sub_details = new OrderSubDetail();
                        $sub_details->detail_id = $details->id;
                        $sub_details->addon_id = $addon_id;
                        $sub_details->total_value = $addon_value;
                        $sub_details->save();

                        $order_value += $addon_value;
                    }
                }
            }

            // Calculate promo, vat, and service charges
            $promo_value = 0;
            $total_order_value = $order_value - $promo_value;
            $vat_value = $this->getVatValue($total_order_value);
            $service_charges = $this->getServiceCharges($total_order_value);
            $final_value = $total_order_value + $vat_value + $service_charges;

            // Update order with calculated values
            $order->order_no = $order_no;
            $order->order_value = $order_value;
            $order->promo_value = $promo_value;
            $order->total_value = $total_order_value;
            $order->vat_value = $vat_value;
            $order->service_charges = $service_charges;
            $order->final_value = $final_value;
            $order->save();

            // Finalize and confirm order if cash method
            if ($order->pay_method == 'cash') {
                $order->confirmed_time = Carbon::now()->toDateTimeString();//time();
                $order->status = 3;  // Mark as confirmed
                $order->save();
            }

            $Response = $this->getOrderDetails($order_id);

            $message = 'Order Successfully saved';
        }
        else {
            $message = 'You cannot update this order.';
        }

        return response()->json([
                    'code'    => '201',
                    'status'  => true,
                    'data'    => $Response,
                    'message' => $message
                        ], 200);
    }

    private function getDiscountValue($discount, $discount_type, $item_value) {
        if ($discount_type == 0) {
            return round(($discount / 100) * $item_value, 2);
        }
        return $discount;
    }

    private function getVatValue($total_order_value) {
        $vat_include = get_vat_value();
        return $vat_include > 0 ? round(($vat_include / 100) * $total_order_value, 2) : 0;
    }

    private function getServiceCharges($total_order_value) {
        $service_charges_include = get_vat_value();
        return $service_charges_include > 0 ? round(($service_charges_include / 100) * $total_order_value, 2) : 0;
    }
}
