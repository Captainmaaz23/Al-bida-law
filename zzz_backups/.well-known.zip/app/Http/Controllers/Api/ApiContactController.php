<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Api\ApiBaseController as BaseController;
use App\Http\Resources\Contact as ContactResource;
use App\Models\GeneralSetting;
use Illuminate\Http\Request;

class ApiContactController extends BaseController {

    public function index() {
        $modelData = GeneralSetting::where('status', 1)->get();

        if ($modelData->isEmpty()) {
            return $this->sendError('Contacts not found.');
        }

        return $this->sendResponse(ContactResource::collection($modelData), 'Contacts retrieved successfully.');
    }

    public function show($title) {
        $modelData = GeneralSetting::where('title', 'like', '%' . $title . '%')->where('status', 1)->get();

        if ($modelData->isEmpty()) {
            return $this->sendError('Contact not found.');
        }

        return $this->sendResponse(ContactResource::collection($modelData), 'Contacts retrieved successfully.');
    }

    public function retMethod(Request $request) {
        $title = $request->input('title', '');

        if (!empty($title)) {
            return $this->show($title);
        }

        return $this->index();
    }
}
