<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Exception;

class ApiBaseController extends Controller {

    public function getKey() {
        return $_key;
    }

    public function sendResponse($result, $message) {
        return response()->json([
            'code' => '201',
            'status' => true,
            'data' => $result,
            'message' => $message
        ], 200);
    }

    public function sendError($error, $errorMessages = [], $code = 404) {
        $response = [
            'code' => '101',
            'status' => false,
            'message' => $error,
        ];

        if (!empty($errorMessages)) {
            $response['data'] = $errorMessages;
        }

        return response()->json($response, $code);
    }

    public function convertExceptionToArray(Exception $e, $response = false) {
        if (!config('app.debug')) {
            $statusCode = $e->getStatusCode();

            switch ($statusCode) {
                case 401:
                    $response['message'] = 'Unauthorized';
                    break;
                case 403:
                    $response['message'] = 'Forbidden';
                    break;
                case 404:
                    $response['message'] = 'Resource Not Found';
                    break;
                case 405:
                    $response['message'] = 'Method Not Allowed';
                    break;
                case 422:
                    $response['message'] = 'Request unable to be processed';
                    break;
                default:
                    $response['message'] = ($statusCode == 500) ? 'Whoops, looks like something went wrong' : $e->getMessage();
                    break;
            }
        }

        return parent::convertExceptionToArray($e, $response);
    }
}