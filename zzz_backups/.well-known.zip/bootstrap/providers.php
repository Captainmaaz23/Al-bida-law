<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\FortifyServiceProvider::class,
    App\Providers\JetstreamServiceProvider::class,
    Barryvdh\DomPDF\ServiceProvider::class,
    Yajra\DataTables\DataTablesServiceProvider::class,
    Laracasts\Flash\FlashServiceProvider::class,
    Spatie\Html\HtmlServiceProvider::class,
];
