<a href="/">
    <img src="/media/logos/life-pharmacy-logo.png" width="46">
</a>

