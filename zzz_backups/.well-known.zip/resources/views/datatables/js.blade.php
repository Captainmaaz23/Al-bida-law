
<script src="{{ asset_url('bundles/datatables/datatables.min.js') }}"></script>
<script src="{{ asset_url('bundles/datatables/DataTables-1.10.16/js/dataTables.bootstrap4.min.js') }}"></script>