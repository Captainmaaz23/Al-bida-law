
<div class="row form-group">
    <div class="col-sm-12">
        <div class="row">
            <div class="col-sm-4">
                <label for="name">Name:</label>
            </div>
            <div class="col-sm-8">
                <p>{{ $Model_Data->u_name }}</p>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-4">
                <label for="phone">Phone:</label>
            </div>
            <div class="col-sm-8">
                <p>{{ $Model_Data->u_phone }}</p>
            </div>
        </div>
        <div class="row">
            <div class="col-sm-4">
                <label for="user_name">User Name:</label>
            </div>
            <div class="col-sm-8">
                <p>{{ $Model_Data->user_name }}</p>
            </div>
        </div>
    </div>
</div>