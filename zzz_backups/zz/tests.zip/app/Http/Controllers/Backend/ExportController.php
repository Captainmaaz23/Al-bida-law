<?php

namespace App\Http\Controllers\Backend;

use App\Http\Controllers\MainController as MainController;
use Auth;
use App\Models\Order;
use App\Repositories\OrderRepository;
use App\Exports\OrdersExport;
use Maatwebsite\Excel\Facades\Excel;

class ExportController extends MainController {

    public function __construct(OrderRepository $repository) {
        $this->repository = $repository;
    }

    public function index($list_type = 'All') {
        return $this->commonListing($list_type);
    }

    public function open_listing($list_type = 'open') {
        return $this->commonListing($list_type);
    }

    public function completed_listing($list_type = 'completed') {
        return $this->commonListing($list_type);
    }

    public function declined_listing($list_type = 'declined') {
        return $this->commonListing($list_type);
    }

    public function cancelled_listing($list_type = 'cancelled') {
        return $this->commonListing($list_type);
    }

    private function commonListing($list_type) {
        $Auth_User = Auth::user();
        $list_title = 'Orders';
        $records = Order::leftJoin('restaurants', 'orders.rest_id', '=', 'restaurants.id')
                        ->leftJoin('app_users', 'orders.user_id', '=', 'app_users.id')
                        ->leftJoin('serve_tables', 'orders.table_id', '=', 'serve_tables.id')
                        ->select(['orders.id', 'orders.order_no', 'serve_tables.title as table_name', 'app_users.name as user_name', 'orders.final_value']);
        switch($list_type){
            case 'open':
                $filter_status = $this->_ORDER_PREPARING;
                $records = $records->where('orders.rest_id', $Auth_User->rest_id)->where('orders.status', $this->_ORDER_PREPARING);
                $list_title = $this->_ORDER_STATUSES[$filter_status].' '.$list_title;
                break;

            case 'completed':
                $filter_status = $this->_ORDER_SERVED;
                $records = $records->where('orders.rest_id', $Auth_User->rest_id)->where('orders.status', $this->_ORDER_SERVED);
                $list_title = $this->_ORDER_STATUSES[$filter_status].' '.$list_title;
                break;
            
            case 'declined':
                $filter_status = $this->_ORDER_DECLINED;
                $records = $records->where('orders.rest_id', $Auth_User->rest_id)->where('orders.status', $this->_ORDER_DECLINED);
                $list_title = $this->_ORDER_STATUSES[$filter_status].' '.$list_title;
                break;

            case 'cancelled':
                $filter_status = $this->_ORDER_CACELLED;
                $records = $records->where('orders.rest_id', $Auth_User->rest_id)->where('orders.status', $this->_ORDER_CACELLED);
                $list_title = $this->_ORDER_STATUSES[$filter_status].' '.$list_title;
                break;

            default:
                $records = $records->where('orders.rest_id', $Auth_User->rest_id)->where('orders.rest_id', $Auth_User->rest_id);
                $list_title = 'All '.$list_title;
                break;            
        }
        $list_title = strtolower(trim(date('Y-m-d').' '.$list_title));
        $list_name = str_replace(' ', '-', $list_title);
        return Excel::download(new OrdersExport($records), $list_name.'.xlsx');
    }
}
